// "use strict";

// const fs = require("mz/fs");
// const {
//     user,
//     calendar,
//     detailed_account,
//     detailed_list,
//     habit,
//     sum
  
// } = require("./init/data");

//  module.exports = app => {
//   app.beforeStart(async () => {
//     // The application will wait for this function to complete before starting
//     await app.model.sync({ force: true }); //生成数据库模型（实例化）
//     await app.model.User.bulkCreate(user);
//     await app.model.Calendar.bulkCreate(calendar);
//     await app.model.DetailedAccount.bulkCreate(detailed_account);
//     await app.model.DetailedList.bulkCreate(detailed_list);
//     await app.model.Habit.bulkCreate(habit);
//     await app.model.Sum.bulkCreate(sum);
//     console.log("插入数据成功");
//   });

// };

