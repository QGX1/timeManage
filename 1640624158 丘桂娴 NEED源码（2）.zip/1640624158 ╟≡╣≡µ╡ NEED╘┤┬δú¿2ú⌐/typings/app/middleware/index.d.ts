// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportChecktoken = require('../../../app/middleware/checktoken');

declare module 'egg' {
  interface IMiddleware {
    checktoken: typeof ExportChecktoken;
  }
}
