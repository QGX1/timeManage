// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCalendar = require('../../../app/model/calendar');
import ExportDetailedAccount = require('../../../app/model/detailed_account');
import ExportDetailedList = require('../../../app/model/detailed_list');
import ExportHabit = require('../../../app/model/habit');
import ExportSum = require('../../../app/model/sum');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Calendar: ReturnType<typeof ExportCalendar>;
    DetailedAccount: ReturnType<typeof ExportDetailedAccount>;
    DetailedList: ReturnType<typeof ExportDetailedList>;
    Habit: ReturnType<typeof ExportHabit>;
    Sum: ReturnType<typeof ExportSum>;
    User: ReturnType<typeof ExportUser>;
  }
}
