// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAccount = require('../../../app/controller/account');
import ExportCalendar = require('../../../app/controller/calendar');
import ExportCheckEmail = require('../../../app/controller/checkEmail');
import ExportCode = require('../../../app/controller/code');
import ExportDetailList = require('../../../app/controller/detailList');
import ExportHabit = require('../../../app/controller/habit');
import ExportHome = require('../../../app/controller/home');
import ExportLogin = require('../../../app/controller/login');
import ExportMoni = require('../../../app/controller/moni');
import ExportNote = require('../../../app/controller/note');
import ExportSum = require('../../../app/controller/sum');

declare module 'egg' {
  interface IController {
    account: ExportAccount;
    calendar: ExportCalendar;
    checkEmail: ExportCheckEmail;
    code: ExportCode;
    detailList: ExportDetailList;
    habit: ExportHabit;
    home: ExportHome;
    login: ExportLogin;
    moni: ExportMoni;
    note: ExportNote;
    sum: ExportSum;
  }
}
