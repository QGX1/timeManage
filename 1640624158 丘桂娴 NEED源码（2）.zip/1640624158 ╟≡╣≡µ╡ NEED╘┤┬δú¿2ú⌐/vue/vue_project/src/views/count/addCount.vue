<template>
  <div class="accountList"> 
    <HeaderTop title="添加清单列表">
        <span slot="right" class="add_habit" @click="addAccount">
          <i class="iconfont icon-21"></i>
        </span>
    </HeaderTop>

    
  </div>  
</template>

<script>
import HeaderTop from '../../components/HeaderTop'
import Account from '../../components/account/addAccount'
export default {
   components: {
    HeaderTop,
    Account
  },
  data() {
    return {
      
    }
  },
  
  methods: {
  }
}
</script>

<style lang="stylus" scoped>

</style>

